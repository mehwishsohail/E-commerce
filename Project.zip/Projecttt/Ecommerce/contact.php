<di?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
if (session_id() == '' || !isset($_SESSION)) {
  session_start();
}

?>

<!doctype html>
<html class="no-js" lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact || BOLT Sports Shop</title>
  <link rel="stylesheet" href="css/foundation.css" />
  <script src="js/vendor/modernizr.js"></script>
  <style>
    body{
    background-image: url(images/stadium.jpg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 100%,95%;
    }
    #f{
      background-color: rgba(0, 0, 0, 0.79);
      border-radius: 2%;
      align: center;
      margin-top : 3%;
      margin-left: 10%;
      width: 80%;
    }
    #d{
      
      text-align: center;
      align: center;
      margin-top : 5%;
      margin-left: 22%;
      width: 60%;
      color: black;
    }
    .c{
    display: inline-block;
    width: 500px;
    height: 200px;
    text-align: center;
    margin-top: 50px ;
    padding: 25px;
}
h4,h5{
  color: white;
}
   
  </style>
</head>

<body>

  <nav class="top-bar" data-topbar role="navigation">
    <ul class="title-area">
      <li class="name">
        <h1><a href="index.php">BOLT Sports Shop</a></h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
    </ul>

    <section class="top-bar-section">
      <!-- Right Nav Section -->
      <ul class="right">
        <li><a href="about.php">About</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="cart.php">View Cart</a></li>
        <li><a href="orders.php">My Orders</a></li>
        <li class="active"><a href="contact.php">Contact</a></li>
        <?php

        if (isset($_SESSION['username'])) {
          echo '<li><a href="account.php">My Account</a></li>';
          echo '<li><a href="logout.php">Log Out</a></li>';
        } else {
          echo '<li><a href="login.php">Log In</a></li>';
          echo '<li><a href="register.php">Register</a></li>';
        }
        ?>
      </ul>
    </section>
  </nav>
  <div id="d">
    <h2><strong>C O N T A C T <br>_______________________</strong></h2>
  </div>
<div id="f">
  <div class="c">
  <h4><strong>Phone No.</strong></h4><br>
  <p>WhatsApp : +92 3349706072</p><hr>
  <p>Landline : +42 3314191761</p><hr>
  <p>Helpline : +42 3314129577</p>
                  
  </div>
  <div class="c">
    <h4><strong>Email Us</strong></h4><br>
    <p>Official Account : <a href="#">bolt@shop.online.com</a> </p><hr>
    <p>Manager Account : <a href="#">abc@gmail.com</a> </p><hr>
    <p>Help Account : <a href="#">help@shop.online.com</a> </p>
    </div>
                  <div class="c">
                  <h4><strong>Location </strong></h4><br>
                  <p>Country/City : Pakistan/Lahore</p><hr>
                  <p>Address : 123-M Block lahore,Pakistan near johar town</p>
                  </div><br><br>
                  <hr>
  
<br>
     <footer>
      <p style="text-align:center;" >We are working for you 24/7.<br>You can contact us any time.Our team will serve you their best.</p><br>
        <p style="text-align:center; font-size:0.8em;">&copy; BOLT Sports Shop. All Rights Reserved.</p><br>
      </footer>
</div>
     

  







  <script src="js/vendor/jquery.js"></script>
  <script src="js/foundation.min.js"></script>
  <script>
    $(document).foundation();
  </script>
</body>

</html>