<?php 
  
   $product_id = array();
   $product_quantity = array();

   $result = $mysqli->query('SELECT * FROM products');
   if($result === FALSE){
     die(mysql_error());
   }

   if($result){

     while($obj = $result->fetch_object()){
echo '<img src="images/products/'.$obj->product_img_name.'"/>';
     }
     $_SESSION['product_id'] = $product_id;

    }
    ?>