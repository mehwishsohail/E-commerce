<?php

//if (session_status() !== PHP_SESSION_ACTIVE) {session_start();} for php 5.4 and above

if (session_id() == '' || !isset($_SESSION)) {
  session_start();
}


?>

<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Us || BOLT Sports Shop</title>
  <link rel="stylesheet" href="css/foundation.css" />
  <script src="js/vendor/modernizr.js"></script>
  <style>
    .c{
      display: inline-block;
    }
    .b{
      text-align: center;
      margin-left: 8%;
    }
  </style>
</head>

<body>

  <nav class="top-bar" data-topbar role="navigation">
    <ul class="title-area">
      <li class="name">
        <h1><a href="index.php">BOLT Sports Shop</a></h1>
      </li>
      <li class="toggle-topbar menu-icon"><a href="#"><span></span></a></li>
    </ul>

    <section class="top-bar-section">
      <!-- Right Nav Section -->
      <ul class="right">
        <li class="active"><a href="about.php">About</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="cart.php">View Cart</a></li>
        <li><a href="orders.php">My Orders</a></li>
        <li><a href="contact.php">Contact</a></li>
        <?php

        if (isset($_SESSION['username'])) {
          echo '<li><a href="account.php">My Account</a></li>';
          echo '<li><a href="logout.php">Log Out</a></li>';
        } else {
          echo '<li><a href="login.php">Log In</a></li>';
          echo '<li><a href="register.php">Register</a></li>';
        }
        ?>
      </ul>
    </section>
  </nav>

<div class="c">
  <img data-interchange="[images/bolt-retina.jpg, (retina)], [images/aboutus.jpg, (large)], [images/bolt-mobile.jpg, (mobile)], [images/aboutus.jpg, (medium)]">
    <noscript><img src="images/aboutus.jpg"></noscript>
    </div>
    <div class="c">
    <h1 style="color:white;" ><strong>" Run After Your Dreams "</strong></h1>
</div>
<br>
    <div class="c">
    <h1 style="color:white;" ><strong>" We Don't Want<br> To Tell Our Dreams.<br> We Want To Show Them "</strong></h1>
</div>
<div class="c">
  <img data-interchange="[images/bolt-retina.jpg, (retina)], [images/about_us.jpg, (large)], [images/bolt-mobile.jpg, (mobile)], [images/about_us.jpg, (medium)]">
    <noscript><img src="images/about_us.jpg"></noscript>
    </div>
    <div class="c">
    <img data-interchange="[images/bolt-retina.jpg, (retina)], [images/abouttuss.png, (large)], [images/bolt-mobile.jpg, (mobile)], [images/abouttuss.png, (medium)]">
    <noscript><img src="images/abouttuss.png"></noscript>
    </div>
    <div class="c">
    <h1 style="color:white;" ><strong>" Run Untill........<br> You Get Your Dreams "</strong></h1>
</div>
    <br><br><br>
    <div class="b"> <img data-interchange="[images/bolt-retina.jpg, (retina)], [images/shoe.jpg, (large)], [images/bolt-mobile.jpg, (mobile)], [images/shoe.jpg, (medium)]">
    <noscript><img src="images/shoe.jpg"></noscript></div><br><br><br>
    <div class="b">
    <h3 style="color:white;" ><strong> We Will Help You To chase Your Dreams.<br> Buy Our New Products And Reboot Yourself.<br> We provide the latest and the moderen products to our customers<br>We are providing our services since 1990.</strong></h3>
</div>
<br><br><br>
    <div class="b"> <img data-interchange="[images/bolt-retina.jpg, (retina)], [images/boltt.png, (large)], [images/bolt-mobile.jpg, (mobile)], [images/boltt.png, (medium)]">
    <noscript><img src="boltt.png"></noscript></div><br><br><br>
    <div class="b">
    <h3 style="color:white;" ><strong> Purchase our products to get intouch with the latest products<br>What's new going in the world of sports<br>This online platform is the #1 online platform for shopping.</strong></h3>
</div>
<br><br><br>
  <div class="row" style="margin-top:30px;">
    <div class="small-12">
      <footer>
        <p style="text-align:center; font-size:0.8em;">&copy; BOLT Sports Shop. All Rights Reserved.</p>
      </footer>

    </div>
  </div>







  <script src="js/vendor/jquery.js"></script>
  <script src="js/foundation.min.js"></script>
  <script>
    $(document).foundation();
  </script>
</body>

</html>