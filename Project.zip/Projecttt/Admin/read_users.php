<?php include("includes/header.php") ?>

<div class="container-fluid py-4">
     <div class="row min-vh-80 h-100">
          <div class="col-12">
               <div class="row">
                    <div class="col-lg-12 position-relative z-index-2">
                         <div class="card">
                              <div class="card-header">
                                   <h4>READ DATA
                                   </h4>
                              </div>
                              <div class="card-body">
                                   <table class="table table-striped">
                                        <thead>
                                             <tr>
                                                  <th scope="col">ID</th>
                                                  <th scope="col">FIRST NAME</th>
                                                  <th scope="col">LAST NAME</th>
                                                  <th scope="col">ADDRESS</th>
                                                  <th scope="col">CITY</th>
                                                  <th scope="col">PIN</th>
                                                  <th scope="col">EMAIL</th>
                                                  <th scope="col">PASSWORD</th>
                                                  <th scope="col">TYPE</th>
                                             </tr>
                                        </thead>
                                        <tbody>

                                             <?php

                                             $servername = "localhost";
                                             $username = "root";
                                             $password = "";
                                             $database = "bolt";

                                             $conn = mysqli_connect($servername, $username, $password, $database);

                                             if (!$conn) {
                                                  // die("Sorry Couldn't connect to database ".mysqli_connect_error());
                                                  echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
                                             } else {

                                                  $fetch_query = "SELECT * FROM users";
                                                  $fetch_query_run = mysqli_query($conn, $fetch_query);

                                                  if (mysqli_num_rows($fetch_query_run) > 0) {

                                                       foreach ($fetch_query_run as $row) {
                                             ?>
                                                            <tr>
                                                                 <td><?php echo $row['id']; ?></td>
                                                                 <td><?php echo $row['fname']; ?></td>
                                                                 <td><?php echo $row['lname']; ?></td>
                                                                 <td><?php echo $row['address']; ?></td>
                                                                 <td><?php echo $row['city']; ?></td>
                                                                 <td><?php echo $row['pin']; ?></td>
                                                                 <td><?php echo $row['email']; ?></td>
                                                                 <td><?php echo $row['password']; ?></td>
                                                                 <td><?php echo $row['type']; ?></td>
                                                                 <td><a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-success">EDIT</a></td>
                                                                 <td>
                                                                      <form action="user_delete.php" method="post">
                                                                           <button type=" submit" name="delete_btn" class="btn btn-danger">DELETE</button>
                                                                           <input style="visibility:hidden;" type="text" class="form-control" name="user_id" value="<?php echo $row['id']; ?>">

                                                                      </form>
                                                                 </td>
                                                            </tr>
                                             <?php
                                                       }
                                                  } else {
                                                       echo "Currently There's No Data <br>";
                                                  }
                                             }
                                             ?>
                                        </tbody>
                                   </table>
                              </div>


                         </div>
                    </div>
               </div>
          </div>

          <?php include("includes/footer.php") ?>