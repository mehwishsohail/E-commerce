<?php include("includes/header.php") ?>





















<div class="container-fluid py-4">
     <div class="row min-vh-80 h-100">
          <div class="col-12">
               <div class="row">
                    <div class="col-lg-12 position-relative z-index-2">
                         <!-- <div class="card card-plain mb-4">
                              <div class="card-body p-3">
                                   <div class="row">
                                        <div class="col-lg-6">
                                             <div class="d-flex flex-column h-100">
                                                  <h2 class="font-weight-bolder mb-0">General Statistics</h2>
                                             </div>

                                        </div>
                                   </div>
                              </div>
                         </div> -->


                         <div class="card">
                              <div class="card-header">
                                   <h4>EDIT DATA
                                        <!-- <a href="insert.php" class="btn btn-primary float-end" style="background-color: #348E38;
       border-color: #348E38;">INSERT</a> -->
                                   </h4>
                              </div>


                              <?php
                              // Connecting to database
                              $servername = "localhost";
                              $username = "root";
                              $password = "";
                              $database = "bolt";

                              $conn = mysqli_connect($servername, $username, $password, $database);

                              if (!$conn) {
                                   // die("Sorry Couldn't connect to database ".mysqli_connect_error());
                                   echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
                              } else {

                                   $id = $_GET['id'];

                                   $fetch_query = "SELECT * FROM PRODUCTS WHERE id='$id' ";
                                   $fetch_query_run = mysqli_query($conn, $fetch_query);

                                   if ($fetch_query_run) {
                                        foreach ($fetch_query_run as $row) {
                              ?>
                                             <div class="card-body">

                                                  <form class="form-horizontal" action="/Project/Admin/products_update.php?id=<?php echo $row['id']; ?>" method="post">
                                                       <div class="form-group">
                                                            <label class="control-label col-sm-2" for="product_code">Product Code:</label>
                                                            <div class="col-sm-10">
                                                                 <input type="text" class="form-control" id="product_code" name="product_code" placeholder="Enter Product Code" value="<?php echo $row['product_code']; ?>">
                                                            </div>
                                                       </div>
                                                       <div class="form-group">
                                                            <label class="control-label col-sm-2" for="product_name">Product Name:</label>
                                                            <div class="col-sm-10">
                                                                 <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter Product Name" value="<?php echo $row['product_name']; ?>">
                                                            </div>
                                                       </div>
                                                       <div class="form-group">
                                                            <label class="control-label col-sm-2" for="product_desc">Product Description:</label>
                                                            <div class="col-sm-10">
                                                                 <input type="text" class="form-control" id="product_desc" name="product_desc" placeholder="Enter Product Description" value="<?php echo $row['product_desc']; ?>">
                                                            </div>
                                                       </div>
                                                       <div class="form-group">
                                                            <label class="control-label col-sm-2" for="product_img_name">Product image name:</label>
                                                            <div class="col-sm-10">
                                                                 <input type="text" class="form-control" id="product_img_name" name="product_img_name" placeholder="Enter Image Name" value="<?php echo $row['product_img_name']; ?>">
                                                            </div>
                                                       </div>
                                                       <div class="form-group">
                                                            <label class="control-label col-sm-2" for="qty">Quantity:</label>
                                                            <div class="col-sm-10">
                                                                 <input type="text" class="form-control" id="qty" name="qty" placeholder="Enter Quantity" value="<?php echo $row['qty']; ?>">
                                                            </div>
                                                       </div>
                                                       <div class="form-group">
                                                            <label class="control-label col-sm-2" for="price">Price:</label>
                                                            <div class="col-sm-10">
                                                                 <input type="text" class="form-control" id="price" name="price" placeholder="Enter Price" value="<?php echo $row['price']; ?>">
                                                            </div>
                                                       </div>
                                                       <br>
                                                       <div class="form-group">
                                                            <div class="col-sm-offset-2 col-sm-10">
                                                                 <button type="submit" class="btn btn-default">Submit</button>
                                                            </div>
                                                       </div>
                                                  </form>
                                             </div>
                              <?php
                                        }
                                   }
                              }
                              ?>



                         </div>
                    </div>
               </div>
          </div>

















          <?php include("includes/footer.php") ?>