<?php include("includes/header.php") ?>



<div class="container-fluid py-4">
     <div class="row min-vh-80 h-100">
          <div class="col-12">
               <div class="row">
                    <div class="col-lg-12 position-relative z-index-2">
                         <!-- <div class="card card-plain mb-4">
                              <div class="card-body p-3">
                                   <div class="row">
                                        <div class="col-lg-6">
                                             <div class="d-flex flex-column h-100">
                                                  <h2 class="font-weight-bolder mb-0">General Statistics</h2>
                                             </div>

                                        </div>
                                   </div>
                              </div>
                         </div> -->


                         <div class="card">
                              <div class="card-header">
                                   <h4>UPDATE DATA
                                        <!-- <a href="insert.php" class="btn btn-primary float-end" style="background-color: #348E38;
    border-color: #348E38;">INSERT</a> -->
                                   </h4>
                              </div>
                              <script>
                              function scrollToDiv(event) {
                                   event.preventDefault();
                                   const target = event.target.getAttribute('data-target');
                                   const div = document.getElementById(target);
                                   div.scrollIntoView({
                                        behavior: 'smooth'
                                   });
                              }

                              function validate_Login(event) {

                                   var name = document.getElementById('gname').value;
                                   var email = document.getElementById('gmail').value;
                                   var phoneNumber = document.getElementById('cphone').value;
                                   var serviceType = document.getElementById('serviceType').value;

                                   var nameRegex = /^[A-Za-z]+$/;
                                   if (name === '') {
                                        alert('Please enter a name.');
                                        return false;
                                   } else if (!nameRegex.test(name)) {
                                        alert('Please enter a valid name with only characters.');
                                        return false;
                                   }

                                   var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                                   if (email === '') {
                                        alert('Please enter an email.');
                                        return false;
                                   } else if (!emailRegex.test(email)) {
                                        alert('Please enter a valid email address.');
                                        return false;
                                   }
                                   var phoneRegex = /^[0-9]{11}$/;
                                   if (phoneNumber === '') {
                                        alert('Please enter a phone number.');
                                        return false;
                                   } else if (!phoneRegex.test(phoneNumber)) {
                                        alert('Please enter a valid 11-digit phone number.');
                                        return false;
                                   }

                                   if (serviceType === '') {
                                        alert('Please select a service type.');
                                        return false;
                                   }
                                   return true;
                              }
                              </script>

                              <?php


                              if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                   $id = $_POST['id'];
                                   $name = $_POST['name'];
                                   $email = $_POST['email'];
                                   $mobile = $_POST['mobile'];
                                   $service = $_POST['drop'];
                                   $message = $_POST['message'];


                                   // Connecting to database
                                   $servername = "localhost";
                                   $username = "root";
                                   $password = "";
                                   $database = "greenland_db";

                                   $conn = mysqli_connect($servername, $username, $password, $database);

                                   if (!$conn) {
                                        // die("Sorry Couldn't connect to database ".mysqli_connect_error());
                                        echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
                                   } else {

                                        $update_query = "UPDATE CUSTOMER SET Customer_Name= '$name',Customer_Email='$email',
                                        Customer_Subject='$service',Customer_Message='$message' WHERE CustomerID='$id'";

                                        $update_query_run = mysqli_query($conn, $update_query);

                                        if ($update_query_run) {
                                             echo '<div class="alert alert-success" role="alert">
                                   Your Data is submitted Successfully!
                         </div>';
                                        } else {
                                             // echo "ERROR ---->". mysqli_error($conn);
                                             echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Try Again!
                         </div>';
                                        }
                                   }
                              }

                         
                              ?>
                              <div class="card-body">
                                   <form action="/AdminDashBoard/admin/update.php" method="post"
                                        onsubmit="return validate_Login()">
                                        <div id="div-to-scroll-to" class="container-fluid quote my-0 py-0"
                                             data-parallax="scroll" data-image-src="img/carousel2.jpg">
                                             <div class="container py-0">
                                                  <div class="row justify-content-center">
                                                       <div class="col-lg-7">
                                                            <div class="bg-white rounded p-0 p-sm-5 wow fadeIn"
                                                                 data-wow-delay="0.5s">

                                                                 <div class="row g-3">
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <input type="text" name="name"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="gname"
                                                                                     placeholder="Gurdian Name"
                                                                                     required>
                                                                                <label for="gname"
                                                                                     style="margin-left:5px">Your
                                                                                     Name</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <input type="email" name="email"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="gmail"
                                                                                     placeholder="Gurdian Email"
                                                                                     required>
                                                                                <label for="gmail">Your Email</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <input type="text" name="mobile"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="cphone"
                                                                                     placeholder="Phone Number"
                                                                                     required>
                                                                                <label for="cphone">Your Mobile</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <select name="drop"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="serviceType">
                                                                                     <option value="" disabled selected>
                                                                                          Select Service Type</option>
                                                                                     <option value="service1">Service 1
                                                                                     </option>
                                                                                     <option value="service2">Service 2
                                                                                     </option>
                                                                                     <option value="service3">Service 3
                                                                                     </option>
                                                                                </select>
                                                                                <label for="serviceType">Service
                                                                                     Type</label>
                                                                           </div>
                                                                      </div>

                                                                      <div class="col-12">
                                                                           <div class="form-floating">
                                                                                <textarea name="message"
                                                                                     class="form-control bg-light border-0"
                                                                                     placeholder="Leave a message here"
                                                                                     id="message" style="height: 100px"
                                                                                     required></textarea>
                                                                                <label for="message">Message</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-12 text-center">
                                                                           <!-- <input type="submit" class="btn btn-primary py-3 px-4" value="Submit"> -->
                                                                           <button class="btn btn-primary py-3 px-4"
                                                                                style="background-color: #348E38;
    border-color: #348E38;" type="submit">Submit Now</button>
                                                                      </div>
                                                                 </div>
                                                            </div>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                   </form>
                              </div>


                         </div>
                    </div>
               </div>
          </div>















          <?php include("includes/footer.php") ?>