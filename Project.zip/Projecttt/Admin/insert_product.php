<?php include("includes/header.php") ?>



<div class="container-fluid py-4">
     <div class="row min-vh-80 h-100">
          <div class="col-12">
               <div class="row">
                    <div class="col-lg-12 position-relative z-index-2">
                         <!-- <div class="card card-plain mb-4">
                              <div class="card-body p-3">
                                   <div class="row">
                                        <div class="col-lg-6">
                                             <div class="d-flex flex-column h-100">
                                                  <h2 class="font-weight-bolder mb-0">General Statistics</h2>
                                             </div>

                                        </div>
                                   </div>
                              </div>
                         </div> -->


                         <div class="card">
                              <div class="card-header">
                                   <h4>INSERT DATA
                                   </h4>
                              </div>


                              <?php


                              if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                   $id = $_POST['id'];
                                   $product_code = $_POST['product_code'];
                                   $product_name = $_POST['product_name'];
                                   $product_desc = $_POST['product_desc'];
                                   $product_img_name = $_POST['product_img_name'];
                                   $qty = $_POST['qty'];
                                   $price = $_POST['price'];


                                   // Connecting to database
                                   $servername = "localhost";
                                   $username = "root";
                                   $password = "";
                                   $database = "bolt";

                                   $conn = mysqli_connect($servername, $username, $password, $database);

                                   if (!$conn) {
                                        // die("Sorry Couldn't connect to database ".mysqli_connect_error());
                                        echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
                                   } else {


                                        $sql = "INSERT INTO `products` (`id`, `product_code`, `product_name`, `product_desc`, `product_img_name`, `qty`,`price`) VALUES ('$id', '$product_code', '$product_name', '$product_desc', '$product_img_name','$qty','$price')";
                                        $result = mysqli_query($conn, $sql);
                                        if ($result) {
                                             echo '<div class="alert alert-success" role="alert">
                                   Your Data is submitted Successfully!
                         </div>';
                                        } else {
                                             // echo "ERROR ---->". mysqli_error($conn);
                                             echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Try Again!
                         </div>';
                                        }
                                   }
                              }


                              ?>
                              <div class="card-body">

                                   <form class="form-horizontal" action="/Project/Admin/insert_product.php" method="post">

                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="product_code">ID:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="id" name="id" placeholder="Enter id">
                                             </div>
                                        </div>




                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="product_code">Product Code:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="product_code" name="product_code" placeholder="Enter Product Code">
                                             </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="product_name">Product Name:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="product_name" name="product_name" placeholder="Enter Product Name">
                                             </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="product_desc">Product Description:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="product_desc" name="product_desc" placeholder="Enter Product Description">
                                             </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="product_img_name">Product image name:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="product_img_name" name="product_img_name" placeholder="Enter Image Name">
                                             </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="qty">Quantity:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="qty" name="qty" placeholder="Enter Quantity">
                                             </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="control-label col-sm-2" for="price">Price:</label>
                                             <div class="col-sm-10">
                                                  <input type="text" class="form-control" id="price" name="price" placeholder="Enter Price">
                                             </div>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                             <div class="col-sm-offset-2 col-sm-10">
                                                  <button type="submit" class="btn btn-default">Submit</button>
                                             </div>
                                        </div>
                                   </form>





                              </div>


                         </div>
                    </div>
               </div>
          </div>















          <?php include("includes/footer.php") ?>