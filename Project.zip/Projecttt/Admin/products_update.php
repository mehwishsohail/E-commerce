<?php include("includes/header.php") ?>



<div class="container-fluid py-4">
     <div class="row min-vh-80 h-100">
          <div class="col-12">
               <div class="row">
                    <div class="col-lg-12 position-relative z-index-2">
                         <!-- <div class="card card-plain mb-4">
                              <div class="card-body p-3">
                                   <div class="row">
                                        <div class="col-lg-6">
                                             <div class="d-flex flex-column h-100">
                                                  <h2 class="font-weight-bolder mb-0">General Statistics</h2>
                                             </div>

                                        </div>
                                   </div>
                              </div>
                         </div> -->


                         <div class="card">
                              <div class="card-header">
                                   <h4>UPDATE DATA
                                        <!-- <a href="insert.php" class="btn btn-primary float-end" style="background-color: #348E38;
    border-color: #348E38;">INSERT</a> -->
                                   </h4>
                              </div>


                              <?php

                              $id = $_GET['id'];
                              if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                   // $id = $_POST['id'];
                                   $product_code = $_POST['product_code'];
                                   $product_name = $_POST['product_name'];
                                   $product_desc = $_POST['product_desc'];
                                   $product_img_name = $_POST['product_img_name'];
                                   $qty = $_POST['qty'];
                                   $price = $_POST['price'];


                                   // Connecting to database
                                   $servername = "localhost";
                                   $username = "root";
                                   $password = "";
                                   $database = "bolt";

                                   $conn = mysqli_connect($servername, $username, $password, $database);

                                   if (!$conn) {
                                        // die("Sorry Couldn't connect to database ".mysqli_connect_error());
                                        echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
                                   } else {

                                        $update_query = "UPDATE products SET product_code= '$product_code',product_name='$product_name',
                                        product_desc='$product_desc',product_img_name='$product_img_name',qty =$qty,
                                        price=$price WHERE id='$id'";

                                        $update_query_run = mysqli_query($conn, $update_query);

                                        if ($update_query_run) {
                                             echo '<div class="alert alert-success" role="alert">
                                   Your Data is submitted Successfully!
                         </div>';
                                        } else {
                                             // echo "ERROR ---->". mysqli_error($conn);
                                             echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Try Again!
                         </div>';
                                        }
                                   }
                              }


                              ?>
                              <h1>UPDATED</h1>


                         </div>
                    </div>
               </div>
          </div>















          <?php include("includes/footer.php") ?>