<?php include("includes/header.php") ?>



<div class="container-fluid py-4">
     <div class="row min-vh-80 h-100">
          <div class="col-12">
               <div class="row">
                    <div class="col-lg-12 position-relative z-index-2">
                         <!-- <div class="card card-plain mb-4">
                              <div class="card-body p-3">
                                   <div class="row">
                                        <div class="col-lg-6">
                                             <div class="d-flex flex-column h-100">
                                                  <h2 class="font-weight-bolder mb-0">General Statistics</h2>
                                             </div>

                                        </div>
                                   </div>
                              </div>
                         </div> -->


                         <div class="card">
                              <div class="card-header">
                                   <h4>EDIT DATA
                                        <!-- <a href="insert.php" class="btn btn-primary float-end" style="background-color: #348E38;
    border-color: #348E38;">INSERT</a> -->
                                   </h4>
                              </div>


                              <?php
                              // Connecting to database
                              $servername = "localhost";
                              $username = "root";
                              $password = "";
                              $database = "greenland_db";

                              $conn = mysqli_connect($servername, $username, $password, $database);

                              if (!$conn) {
                                   // die("Sorry Couldn't connect to database ".mysqli_connect_error());
                                   echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
                              } else {

                                   $id = $_GET['id'];

                                   $fetch_query = "SELECT * FROM CUSTOMER WHERE CustomerID='$id' ";
                                   $fetch_query_run = mysqli_query($conn, $fetch_query);

                                   if ($fetch_query_run) {
                                        foreach ($fetch_query_run as $row) {
                              ?>
                              <div class="card-body">
                                   <form action="/AdminDashBoard/admin/update.php?id=<?php echo $row['CustomerID']; ?>"
                                        method="post" onsubmit="return validate_Login()">
                                        <div id="div-to-scroll-to" class="container-fluid quote my-0 py-0"
                                             data-parallax="scroll" data-image-src="img/carousel2.jpg">
                                             <div class="container py-0">
                                                  <div class="row justify-content-center">
                                                       <div class="col-lg-7">
                                                            <div class="bg-white rounded p-0 p-sm-5 wow fadeIn"
                                                                 data-wow-delay="0.5s">

                                                                 <div class="row g-3">


                                                                      <div class="form-floating"
                                                                           style="visibility:hidden;">
                                                                           <input type="text" name="id"
                                                                                class="form-control bg-light border-0"
                                                                                placeholder="Gurdian Name"
                                                                                value="<?php echo $row['CustomerID']; ?>"
                                                                                required>
                                                                           <label for="gname"
                                                                                style="margin-left:5px">ID-NON
                                                                                CHANGEABLE</label>
                                                                      </div>



                                                                      <div class="col-sm-6">




                                                                           <div class="form-floating">
                                                                                <input type="text" name="name"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="gname"
                                                                                     placeholder="Gurdian Name"
                                                                                     value="<?php echo $row['Customer_Name']; ?>"
                                                                                     required>
                                                                                <label for="gname"
                                                                                     style="margin-left:5px">Your
                                                                                     Name</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <input type="email" name="email"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="gmail"
                                                                                     placeholder="Gurdian Email"
                                                                                     value="<?php echo $row['Customer_Email']; ?>"
                                                                                     required>
                                                                                <label for="gmail">Your Email</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <input type="text" name="mobile"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="cphone"
                                                                                     placeholder="Phone Number"
                                                                                     value="<?php echo $row['Customer_Mobile']; ?>"
                                                                                     required>
                                                                                <label for="cphone">Your Mobile</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-sm-6">
                                                                           <div class="form-floating">
                                                                                <select name="drop"
                                                                                     class="form-control bg-light border-0"
                                                                                     id="serviceType" required>
                                                                                     <option value="" disabled selected>
                                                                                          Select Service Type</option>
                                                                                     <option value="service1">Service 1
                                                                                     </option>
                                                                                     <option value="service2">Service 2
                                                                                     </option>
                                                                                     <option value="service3">Service 3
                                                                                     </option>
                                                                                </select>
                                                                                <label for="serviceType">Service
                                                                                     Type</label>
                                                                           </div>
                                                                      </div>

                                                                      <div class="col-12">
                                                                           <div class="form-floating">
                                                                                <textarea name="message"
                                                                                     class="form-control bg-light border-0"
                                                                                     placeholder="Leave a message here"
                                                                                     id="message" style="height: 100px"
                                                                                     value="<?php echo $row['Customer_Message']; ?>"
                                                                                     required></textarea>
                                                                                <label for="message">Message</label>
                                                                           </div>
                                                                      </div>
                                                                      <div class="col-12 text-center">
                                                                           <!-- <input type="submit" class="btn btn-primary py-3 px-4" value="Submit"> -->
                                                                           <button class="btn btn-primary py-3 px-4"
                                                                                style="background-color: #348E38;
                                                                           border-color: #348E38;" type="submit">UPDATE
                                                                           </button>
                                                                      </div>
                                                                 </div>
                                                            </div>
                                                       </div>
                                                  </div>
                                             </div>
                                        </div>
                                   </form>
                              </div>
                              <?php
                                        }
                                   }
                              }
                              ?>



                         </div>
                    </div>
               </div>
          </div>















          <?php include("includes/footer.php") ?>