<?php
if(isset($_POST['delete_btn']))
{
     $servername = "localhost";
     $username = "root";
     $password = "";
     $database = "greenland_db";

     $conn = mysqli_connect($servername, $username, $password, $database);

     if (!$conn) {
          // die("Sorry Couldn't connect to database ".mysqli_connect_error());
          echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not submitted Please Try Again!
                         </div>';
     } 
     else {
          $id = $_POST['user_id'];
          $delete_query = "DELETE FROM CUSTOMER WHERE CUSTOMERID='$id'";
          $delete_query_run = mysqli_query($conn, $delete_query);
          if($delete_query_run){
               header('location:index.php');
          }
          else{
               echo '<div class="alert alert-danger" role="alert">
                                   Your Data is not Deleted Try Again!
                         </div>';
          }
     }
     
}



?>